# dataset_imagens > 2022-08-20 8:53am
https://universe.roboflow.com/object-detection/dataset_imagens

Provided by Roboflow
License: CC BY 4.0

